export class RequistionDetails {

    OrderingProviderNPI: string="";
    OrderingProviderName: string ="";

    accountNumber: string="";
    pFname: string ="";
    pLname:string ="";
    pMname:string="";
    pDOB: string ="";
    pGender:string="";
    pAddress:string="";
    pCity:string="";
    pState:string="";
    pZip:string="";
    pPhoneNo:string="";
    pEmail:string="";

    OrderedTestCodeList:string="";
    DiagnosisCodeList:string="";

    BillingType:string="";

    gFname:string="";
    gMname:string="";
    gLname:string="";
    gAddress:string="";
    gCity:string="";
    gState:string="";
    gZip:string="";
    gPhone:string="";

    iCompanyName:string="";
    iCompanyId:string="";
iGroupNumber:string="";
iPolicyNumber:string="";



InsuredRelationshiptoPatient:string="";
InsuredFirstName:string="";
InsuredLastName:string="";
InsuredMiddleName:string="";
InsuredAddress:string="";
InsuredCity:string="";
InsuredState:string="";
InsuredZipCode:string="";

SecondaryInsuranceCompanyName:string="";
SecondaryInsuranceCompanyId:string="";
SecondaryInsuranceGroupNumber:string="";
SecondaryInsurancePolicyNumber:string="";
SecondaryInsuredRelationshiptoPatient:string="";
SecondaryInsuredFirstName:string="";
SecondaryInsuredLastName:string="";
SecondaryInsuredMiddleName:string="";
SecondaryInsuredAddress:string="";
SecondaryInsuredCity:string="";
SecondaryInsuredState:string="";
SecondaryInsuredZipCode:string="";

OrderLevelComment:string="";
PlacerOrderNumber:string="";
AskAtOrderEntryList:string="";

    

}
