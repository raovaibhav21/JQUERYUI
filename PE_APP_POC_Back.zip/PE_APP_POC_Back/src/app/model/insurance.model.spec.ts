import { Insurance } from './insurance.model';

describe('Insurance', () => {
  it('should create an instance', () => {
    expect(new Insurance()).toBeTruthy();
  });
});
