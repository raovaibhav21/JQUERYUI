export class funcRequest {
    filename: string="";
    bytestr: string="";
}
