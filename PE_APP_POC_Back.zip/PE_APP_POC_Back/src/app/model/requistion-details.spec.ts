import { RequistionDetails } from './requistion-details';

describe('RequistionDetails', () => {
  it('should create an instance', () => {
    expect(new RequistionDetails()).toBeTruthy();
  });
});
