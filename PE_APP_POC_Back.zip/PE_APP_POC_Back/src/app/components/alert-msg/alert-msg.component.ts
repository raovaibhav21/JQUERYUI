import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-alert-msg',
  templateUrl: './alert-msg.component.html',
  styleUrls: ['./alert-msg.component.css']
})
export class AlertMsgComponent implements OnInit {

  @ViewChild('alert',{static : true}) alert :ElementRef | undefined;

  @Input() handleAlert :Subject<any> | undefined;

  msg: any = {};
  
  constructor() { }

  ngOnInit(): void {
      this.handleAlert?.subscribe(msg=>{
        this.msg = msg;
        console.log("handle alert",msg);
      });


      setTimeout(()=>{
        this.msg.IsShow = false;
      },1000*30);
  }

  closeAlert(){
      this.alert?.nativeElement.remove();
  }

}