import { Component, Input, OnInit } from '@angular/core';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { IDrivingLicence } from 'src/app/model/idriving-licence.model';
import { DrivingLicence } from 'src/app/model/driving-licence.model';
import { NgbModal, ModalDismissReasons, NgbDateStruct, NgbCalendar, NgbDate } from '@ng-bootstrap/ng-bootstrap';
import { Insurance } from 'src/app/model/insurance.model';
import { WebcamImage } from 'ngx-webcam';
import { IMyDpOptions } from 'mydatepicker';
import { FileUploadService } from 'src/app/Services/file-upload.service';
import { RequistionDetails } from 'src/app/model/requistion-details';
import { DataSharingService } from 'src/app/Services/data-sharing.service';
import { funcRequest } from 'src/app/model/func-request.model';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {
  @Input() CardHeader: string = "";

  closeResult: string = '';
  selectedFiles?: FileList;
  progressInfos: any[] = [];
  message: string[] = [];

  dlDetails: any = null;
  insuranceDetails: any = null;
  requistionDetails: any = null;

  previews: string[] = [];
  imageInfos?: Observable<any>;
  isEditView: boolean = false;
  //model: NgbDateStruct|null;
  date: { year: number, month: number } | null;
  webcamImage: any = null;
  enableUpload: boolean = false;

  alertMsg: string = "";
  handleAlert: Subject<any> = new Subject();

  areYouInsuranced: boolean = false;
  constructor(private uploadService: FileUploadService, private modalService: NgbModal, private calendar: NgbCalendar,
  private dataSharingService: DataSharingService) {
    //this.dlDetails=new DrivingLicence();
    this.date = null
    this.model = null
  }

  public myDatePickerOptions: IMyDpOptions =
    {
      dateFormat: 'mm/dd/yyyy',
    }
  public model: any = { date: { year: 2022, month: 1, date: 6 } };

  ngOnInit(): void {
    this.imageInfos = this.uploadService.getFiles();
    if (this.CardHeader == 'Confirm') {
      this.loadData();

    }
    this.requistionDetails = null;

   

  }
  selectFiles(event: any): void {


    this.message = [];
    this.progressInfos = [];
    this.selectedFiles = event.target.files;

    this.previews = [];
    if (this.selectedFiles && this.selectedFiles[0]) {
      this.enableUpload = true;
      const numberOfFiles = this.selectedFiles.length;
      for (let i = 0; i < numberOfFiles; i++) {
        const reader = new FileReader();

        reader.onload = (e: any) => {
         // console.log(e.target.result);
          this.previews.push(e.target.result);

        };
        reader.readAsDataURL(this.selectedFiles[i]);

        //console.log('--------',this.selectedFiles[i]);
      }
      this.uploadFiles();

    }
  }

  takeSnap(content: any) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  handleImage(webcamImage: WebcamImage) {
    this.previews = [];
    this.previews.push(webcamImage.imageAsDataUrl);
    //this.selectedFiles.push(webcamImage.imageAsDataUrl);
    this.enableUpload = true;
    this.webcamImage = webcamImage.imageAsDataUrl;
    this.modalService.dismissAll();
    this.uploadFiles();
    //   const arr = this.webcamImage.imageAsDataUrl.split(",");
    // const mime = arr[0].match(/:(.*?);/)[1];
    // const bstr = atob(arr[1]);
    // let n = bstr.length;
    // const u8arr = new Uint8Array(n);
    // while (n--) {
    //   u8arr[n] = bstr.charCodeAt(n);
    // }
    // const file: File = new File([u8arr], "webCamCapture", { type: "image/jpeg" })
    // this.selectedFil

  }

  uploadFiles(): void {
    this.message = [];
    this.loadData();
    if (this.selectedFiles) {
      for (let i = 0; i < this.selectedFiles.length; i++) {
        this.upload(i, this.selectedFiles[i]);


      }
    }


    this.handleAlert.next({ IsShow: true, msg: 'Please review your information & click on edit icon  to edit <br/> the information or click on next to proceed.' });
  }

  toggleCard() {
    this.isEditView = !this.isEditView;
  }
  
  LoadDLData(body:any)
  {
    if(body==null|| body==undefined)
    return;
    var res= JSON.parse(JSON.stringify(body));
    this.dlDetails = new DrivingLicence();
    if(res!= null)
    {
    this.dlDetails.firstName = res.FirstName;
    this.dlDetails.lastName = res.LastName;
    this.dlDetails.dateofbirth =res.DateOfBirth;
    this.dlDetails.dlId = res.DocumentNumber;
    this.dlDetails.address = res.Address;
    this.dlDetails.gender = "Male";
    }
  }
  loadData() {
    if(this.dlDetails==null)
    {
    this.dlDetails = new DrivingLicence();
    this.dlDetails.firstName = "Jon";
    this.dlDetails.lastName = "James";
    this.dlDetails.dateofbirth = "01/03/2002";
    this.model = { date: { year: 2002, month: 1, day: 3 } };
    }
    
    if (this.CardHeader == 'Insurance' || this.CardHeader == 'Confirm') {
      this.insuranceDetails = new Insurance();
      this.insuranceDetails.name = "John Chung";
      this.insuranceDetails.memberId = "87867809"
      this.insuranceDetails.groupNumber = "87867809"
      this.insuranceDetails.payerId = "87867809"
      this.insuranceDetails.companyName = "United Healthcare"
    }
    
    this.requistionDetails = new RequistionDetails();

    this.requistionDetails.OrderingProviderNPI = "";
    this.requistionDetails.OrderingProviderName = "";

    this.requistionDetails.BillingType = 'Insurance';
    this.requistionDetails.patientId = 'ES123456';
    this.requistionDetails.accountNumber= '12364888';
    this.requistionDetails.pFname= 'James';
    this.requistionDetails.pMname = "NJM";
    this.requistionDetails.pLname = 'Chung';
    this.requistionDetails.pDOB = '12-12-2010';
    this.requistionDetails.pGender = 'Chung';
    this.requistionDetails.pAddress = 'Address';
    this.requistionDetails.pState = 'State';
    this.requistionDetails.pCity = 'City';
    this.requistionDetails.pZip = '21245';

    this.requistionDetails.OrderedTestCodeList = "";
    this.requistionDetails.DiagnosisCodeList = "";

    this.requistionDetails.gFname = "";
    this.requistionDetails.gMname = "";
    this.requistionDetails.gAddress = "";
    this.requistionDetails.gCity = "";
    this.requistionDetails.gState = "";
    this.requistionDetails.gZip = "";
    this.requistionDetails.gPhone = "";

    this.requistionDetails.iCompanyName = "";
    this.requistionDetails.iCompanyId = "";
    this.requistionDetails.iGroupNumber = "";
    this.requistionDetails.iPolicyNumber = "";
    this.requistionDetails.InsuredRelationshiptoPatient = "Self";

    this.requistionDetails.InsuredFirstName = "";
    this.requistionDetails.InsuredLastName  = "";
    this.requistionDetails.InsuredMiddleName  = "";
    this.requistionDetails.InsuredAddress = "";
    this.requistionDetails.InsuredCity = "";
    this.requistionDetails. InsuredState = "";
    this.requistionDetails. InsuredZipCode = "";
    
    this.requistionDetails.SecondaryInsuranceCompanyName = "";
    this.requistionDetails.SecondaryInsuranceCompanyId = "";
    this.requistionDetails.SecondaryInsuranceGroupNumber = "";
    this.requistionDetails.SecondaryInsurancePolicyNumber = "";
    this.requistionDetails.SecondaryInsuredRelationshiptoPatient = "";
    this.requistionDetails.SecondaryInsuredFirstName = "";
    this.requistionDetails.SecondaryInsuredLastName = "";
    this.requistionDetails.SecondaryInsuredMiddleName = "";
    this.requistionDetails.SecondaryInsuredAddress = "";
    this.requistionDetails.SecondaryInsuredCity = "";
    this.requistionDetails.SecondaryInsuredState = "";
    this.requistionDetails.SecondaryInsuredZipCode = "";

   
  }
  upload(idx: number, file: File): void {
    this.progressInfos[idx] = { value: 100, fileName: file.name };

    if (file) {
      this.loadData();
      console.log(file.text());
      this.uploadService.convertFile(file).subscribe((base64)=>{
        var request= new funcRequest();
           request.bytestr = base64;
           request.filename=file.name.replace(" ","_");
      

      this.uploadService.upload(request).subscribe({
        next: (event: any) => {
          if (event.type === HttpEventType.UploadProgress) {
            this.progressInfos[idx].value = Math.round(100 * event.loaded / event.total);
          } else if (event instanceof HttpResponse) {
            const msg = 'Uploaded the file successfully: ' + file.name;
            console.log(msg);
            console.log(event.body);
            this.message.push(msg);
            this.LoadDLData(event.body);
            this.imageInfos = this.uploadService.getFiles();
          }
        },
        error: (err: any) => {
          this.progressInfos[idx].value = 0;
          const msg = 'Could not upload the file: ' + file.name;
          this.message.push(msg);
        }});

      });
    }
  }


  IsInsuredRequired(){
     return this.requistionDetails.InsuredRelationshiptoPatient == 'Self' ? false : true;
  }


  areYouInsurancedYes:boolean = false;
  areYouInsurancedNo:boolean = false;
  areYouInsured(value: any){


    console.log(value);
      if(value == 'areYouInsurancedYes'){
        this.areYouInsurancedYes =true;
        this.areYouInsurancedNo = false;
      }else if(value == "areYouInsurancedNo"){
        this.areYouInsurancedNo = true;
        this.areYouInsurancedYes = false;
      }
  }


}
