import { Component, OnInit } from '@angular/core';
import { of, Subject } from 'rxjs';
import { NgWizardConfig, NgWizardService, StepChangedArgs, StepValidationArgs, STEP_STATE, THEME } from 'ng-wizard';
import { DataSharingService } from 'src/app/Services/data-sharing.service';

@Component({
  selector: 'app-main-wizard',
  templateUrl: './main-wizard.component.html',
  styleUrls: ['./main-wizard.component.css']
})
export class MainWizardComponent implements OnInit {
  
  handleAlert: Subject<any> = new Subject();
  areYouInsuranced: boolean = true;
  ngOnInit(): void {
    
  }
    constructor(private ngWizardService: NgWizardService, private dataSharingService:DataSharingService){
    
      this.hideAndDisplayFinishButton("d-none");
    }
   stepStates = {
    normal: STEP_STATE.normal,
    disabled: STEP_STATE.disabled,
    error: STEP_STATE.error,
    hidden: STEP_STATE.hidden
  };
  config: NgWizardConfig = {
    selected: 0,
    theme: THEME.dots,
    toolbarSettings: {    
      toolbarExtraButtons: [
        { text: 'Finish', class: 'btn btn-info', event: () => { alert("Finished!!!"); } }
      ],
    }
  };
  showPreviousStep(event?: Event) {
    this.ngWizardService.previous();
  }
  showNextStep(event?: Event) {
    this.ngWizardService.next();
  }
  resetWizard(event?: Event) {
    this.ngWizardService.reset();
  }
  setTheme(theme: THEME) {
    this.ngWizardService.theme(theme);
  }
  stepChanged(args: StepChangedArgs) {
   // console.log(args.step);

    
    if(args.step.title == 'Confirm'){
      this.hideAndDisplayFinishButton("btn btn-info");
      this.handleAlert.next({IsShow: true,msg:'Please review your information & click on edit icon  to edit <br/> the information or click on finish to submit the form.'});

    }
    else
    {
      this.hideAndDisplayFinishButton("d-none");
    }
  }
  isValidTypeBoolean: boolean = true;
  isValidFunctionReturnsBoolean(args: StepValidationArgs) {
    return true;
  }
  isValidFunctionReturnsObservable(args: StepValidationArgs) {
    return of(true);
  }
hideAndDisplayFinishButton(style:string)
{
  var seetings=this.config.toolbarSettings;
  if(seetings!= null)
  {
    var tButtons=seetings.toolbarExtraButtons;
    if(tButtons!=null )
    {
      tButtons[0].class=style;
    }
  }
}
  
  }