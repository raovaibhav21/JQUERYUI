
import { Component, ElementRef, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-intro-screen',
  templateUrl: './intro-screen.component.html',
  styleUrls: ['./intro-screen.component.css']
})
export class IntroScreenComponent implements OnInit {


  constructor(private router: Router, private elementRef: ElementRef) { }

  ngOnInit(): void {
     
  }

  fillOnlineForm(){
    
    this.router.navigate(['checkIn']);
  }

  ngOnDestroy(){
 
        this.elementRef.nativeElement.remove();
  }

}