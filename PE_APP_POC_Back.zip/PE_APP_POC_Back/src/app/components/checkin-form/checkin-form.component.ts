import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkin-form',
  templateUrl: './checkin-form.component.html',
  styleUrls: ['./checkin-form.component.css']
})
export class CheckinFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
