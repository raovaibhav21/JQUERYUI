import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class APIServiceService {

  imageUploadUrl = "";

  constructor(private httpClient:HttpClient) { }

  uploadImageToServer(data: any){
     return this.httpClient.post<any>(this.imageUploadUrl,data);
  }
}
