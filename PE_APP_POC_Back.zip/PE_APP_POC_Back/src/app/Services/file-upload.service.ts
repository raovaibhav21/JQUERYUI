import { Injectable } from '@angular/core';
import { observable, Observable, ReplaySubject } from 'rxjs';
import { HttpClient, HttpRequest, HttpEvent, HttpHeaders, HttpEventType } from '@angular/common/http';
import { funcRequest } from '../model/func-request.model';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

    private baseUrl = environment.apiUrl;
  
    constructor(private http: HttpClient) { }
    convertBlobToBase64 = (blob: any) => new Promise((resolve, reject) => {
      const reader = new FileReader;
      reader.onerror = reject;
      reader.onload = () => {
          resolve(reader.result);
      };
      reader.readAsDataURL(blob);
  });
result:any="";
 async getFileData(file:any) {
  this.result=await this.convertBlobToBase64(file)
 }
    upload(request: funcRequest): Observable<HttpEvent<any>> {
    
      var header= new HttpHeaders();
      header.append('Content-Type', 'application/json');
      header.append('Accept', 'application/json');
      header.append('Access-Control-Allow-Origin', 'http://localhost:4200');

  
  
      const req = new HttpRequest('POST', `${this.baseUrl}/testing`, JSON.stringify(request), {
        headers: header
      });
      return this.http.request(req);
      
    }
  
    getFiles(): Observable<any> {
      return this.http.get(`${this.baseUrl}/files`);
    }
    
    convertFile(file : File) : Observable<string> {
      debugger;
      const result = new ReplaySubject<string>(1);
      const reader = new FileReader();
      reader.readAsBinaryString(file);
      reader.onload =  (event) =>{ 
        var res=event.target?.result;
        if(res!= null)
        {
          result.next(btoa(res.toString()));
        }
      };
      return result;
    }
  }