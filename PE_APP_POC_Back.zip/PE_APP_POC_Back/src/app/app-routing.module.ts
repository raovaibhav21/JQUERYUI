import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckinFormComponent } from './components/checkin-form/checkin-form.component';
import { IntroScreenComponent } from './components/intro-screen/intro-screen.component';
import { MainWizardComponent } from './components/main-wizard/main-wizard.component';


const routes: Routes =[
  {path:'',component : IntroScreenComponent},
  {path:'checkIn',component : CheckinFormComponent},
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
