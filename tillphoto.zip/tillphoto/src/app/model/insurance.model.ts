export class Insurance {
    name:string="";
    memberId:string="";
    groupNumber:string="";
    payerId:string="";    
}
