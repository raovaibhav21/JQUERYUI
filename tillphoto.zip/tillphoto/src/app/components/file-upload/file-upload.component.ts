import { Component, Input, OnInit } from '@angular/core';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FileUploadService } from 'src/app/services/file-upload.service';
import { IDrivingLicence } from 'src/app/model/idriving-licence.model';
import { DrivingLicence } from 'src/app/model/driving-licence.model';
import {NgbModal, ModalDismissReasons,NgbDateStruct, NgbCalendar, NgbDate} from '@ng-bootstrap/ng-bootstrap';
import { Insurance } from 'src/app/model/insurance.model';
import { WebcamImage } from 'ngx-webcam';


@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {
  @Input() CardHeader:string="";
  closeResult: string = '';
  selectedFiles?: FileList;
  progressInfos: any[] = [];
  message: string[] = [];
  dlDetails:any=null;
  insuranceDetails:any=null;
  previews: string[] = [];
  imageInfos?: Observable<any>;  
  isEditView:boolean=false;
  model: NgbDateStruct|null;
  date: {year: number, month: number}|null;
  webcamImage:any=null;
enableUpload:boolean=false;
  constructor(private uploadService: FileUploadService, private modalService: NgbModal,private calendar: NgbCalendar) { 
    //this.dlDetails=new DrivingLicence();
    this.date=null
    this.model=null
  }

  ngOnInit(): void {
    this.imageInfos = this.uploadService.getFiles();
    if(this.CardHeader=='Confirm')
    {
      this.loadData();
    }
  }
  selectFiles(event: any): void {
    this.message = [];
    this.progressInfos = [];
    this.selectedFiles = event.target.files;
  
    this.previews = [];
    if (this.selectedFiles && this.selectedFiles[0]) {
      this.enableUpload=true;
      const numberOfFiles = this.selectedFiles.length;
      for (let i = 0; i < numberOfFiles; i++) {
        const reader = new FileReader();
  
        reader.onload = (e: any) => {
          console.log(e.target.result);
          this.previews.push(e.target.result);
        };
  
        reader.readAsDataURL(this.selectedFiles[i]);
      }
    }
  }
takeSnap(content:any)
{
  this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    this.closeResult = `Closed with: ${result}`;
  }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  });
}
private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return  `with: ${reason}`;
  }
}
handleImage(webcamImage: WebcamImage) {
  this.previews = [];
  this.previews.push(webcamImage.imageAsDataUrl);
  //this.selectedFiles.push(webcamImage.imageAsDataUrl);
  this.enableUpload=true;
  this.webcamImage = webcamImage.imageAsDataUrl;
  this.modalService.dismissAll();

//   const arr = this.webcamImage.imageAsDataUrl.split(",");
// const mime = arr[0].match(/:(.*?);/)[1];
// const bstr = atob(arr[1]);
// let n = bstr.length;
// const u8arr = new Uint8Array(n);
// while (n--) {
//   u8arr[n] = bstr.charCodeAt(n);
// }
// const file: File = new File([u8arr], "webCamCapture", { type: "image/jpeg" })
// this.selectedFil
  
}

  uploadFiles(): void {
    this.message = [];  
    this.loadData();
    if (this.selectedFiles) {
      for (let i = 0; i < this.selectedFiles.length; i++) {
        this.upload(i, this.selectedFiles[i]);
      }
    }
  }
  
  toggleCard()
  {
    this.isEditView=!this.isEditView;
  }
  loadData()
  {
    this.dlDetails= new DrivingLicence();
    this.dlDetails.firstName="Jon";
    this.dlDetails.lastName="James";
    this.dlDetails.dateofbirth="2001/01/03";
    this.model = new NgbDate(2001,1,2);
  
    this.dlDetails.dlId="LDX 123";
    this.dlDetails.address ="Address him value";
    this.dlDetails.gender="Female";
if(this.CardHeader=='Insurance'||this.CardHeader=='Confirm')
{
    this.insuranceDetails= new Insurance();
    this.insuranceDetails.name="John Chung";
    this.insuranceDetails.memberId="87867809"
    this.insuranceDetails.groupNumber="87867809"
    this.insuranceDetails.payerId="87867809"
}
}
  upload(idx: number, file: File): void {
    this.progressInfos[idx] = { value: 0, fileName: file.name };

    if (file) {
    this.loadData();
      // this.uploadService.upload(file).subscribe({
      //   next: (event: any) => {
      //     if (event.type === HttpEventType.UploadProgress) {
      //       this.progressInfos[idx].value = Math.round(100 * event.loaded / event.total);
      //     } else if (event instanceof HttpResponse) {
      //       const msg = 'Uploaded the file successfully: ' + file.name;
      //       this.message.push(msg);
      //       this.imageInfos = this.uploadService.getFiles();
      //     }
      //   },
      //   error: (err: any) => {
      //     this.progressInfos[idx].value = 0;
      //     const msg = 'Could not upload the file: ' + file.name;
      //     this.message.push(msg);
      //   }});
    }
  }


}
